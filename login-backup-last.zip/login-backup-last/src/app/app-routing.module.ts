import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { GuestLoginComponent } from './guest-login/guest-login.component';
import { OwnerLoginComponent } from './owner-login/owner-login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SelectUserTypeComponent } from './select-user-type/select-user-type.component';
import { WelcomeScreenComponent } from './welcome-screen/welcome-screen.component';


const routes: Routes = [
      { path: 'select-user-type', component: SelectUserTypeComponent },
      { path: 'owner-login', component: OwnerLoginComponent },
      { path: 'guest-login', component: GuestLoginComponent },
      { path: 'forgot-password', component: ForgotPasswordComponent },
      { path: 'welcome-screen', component: WelcomeScreenComponent },
      { path: '', redirectTo: '/select-user-type', pathMatch: 'full'},
      { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
