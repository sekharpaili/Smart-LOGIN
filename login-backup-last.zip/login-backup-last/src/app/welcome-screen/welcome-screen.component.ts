import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-screen',
  templateUrl: './welcome-screen.component.html',
  styleUrls: ['./welcome-screen.component.scss']
})
export class WelcomeScreenComponent implements OnInit {

  public userType: any;
  constructor() { }

  ngOnInit(): void {
    this.userType = JSON.parse(localStorage.getItem('userType'));
  }

}
