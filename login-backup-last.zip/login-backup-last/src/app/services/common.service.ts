import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  public apiUrl = 'https://jptest.livesmart.co.jp/external/v1/fb/locobuzz/ext/login?';

  public senderId: any;
  public pageId: any;
  public channelId: any;
  headers;
  constructor(private http: HttpClient) {
    this.headers = new HttpHeaders();
    this.headers.append('Access-Control-Allow-Origin', '*');
  }

  getUserStatus(senderId: any, pageId: any, channelId: any): Observable<any> {
    this.senderId = senderId;
    this.pageId = pageId;
    this.channelId = channelId;
    return this.http
      .get(`https://jptest.livesmart.co.jp/external/v1/fb/locobuzz/ext/login?
      sender_id=${senderId}&page_id=${pageId}&channel_id=${channelId}`, {responseType: 'text'});
  }

  ownerLogin(ownerName: any, ownerPassword: any): Observable<any> {

    const body = {
      email: ownerName,
      senderId: this.senderId,
      pageId: this.pageId,
      channelId: this.channelId,
      password: ownerPassword
    };

    return this.http.post<string>(`https://jptest.livesmart.co.jp/external/v1/fb/locobuzz/ext/login?
        sender_id=${this.senderId}&page_id=${this.pageId}&channel_id=${this.channelId}`, body,  {responseType: 'text' as 'json'});

  }

  guestLogin(loginCode: any, ): Observable<any> {

    const body = {
      login_code: loginCode,
      app_device_token_id: 'FacebookBot',
      device_type: 'LINE'
    };

    return this.http.post<string>(`https://jptest.livesmart.co.jp/v3/user/v3/guest/login`, body);
  }

  liveSmartLoginStatus(payLoad) {
    return this.http.post<string>(`https://lsanalytics1.livesmart.co.jp/Livesmart/LiveSmartLoginStatus`,
                                  payLoad, {responseType: 'text' as 'json'});
  }

}
