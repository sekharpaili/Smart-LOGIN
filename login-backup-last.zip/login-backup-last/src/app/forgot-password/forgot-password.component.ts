import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit, OnDestroy {

  userType: any;
  guestMessage: any = false;

  constructor() { }

  ngOnInit(): void {
    this.userType = localStorage.getItem('forgot-password');
    if (this.userType !== undefined) {
      if (this.userType === 'guest') {
        this.guestMessage = true;
      }
      if (this.userType === 'owner') {
        this.guestMessage = false;
      }
    }
  }

  ngOnDestroy() {
    localStorage.removeItem('forgot-password');
  }

}
