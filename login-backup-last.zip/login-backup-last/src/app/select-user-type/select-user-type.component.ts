import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

// import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-select-user-type',
  templateUrl: './select-user-type.component.html',
  styleUrls: ['./select-user-type.component.scss']
})
export class SelectUserTypeComponent implements OnInit {

  public userType: string;
  public languageObject: any;
  public selectedLanguage = 'en';

  constructor( private router: Router ) {
    this.selectedLanguage = localStorage.getItem('selectedLanguage');
  }

  ngOnInit(): void {
    // this.languageObject = JSON.parse(localStorage.getItem("languageObject"));
    this.getUserType(this.userType);
  }

  getUserType(uType: string) {
      if (uType !== undefined) {
        localStorage.setItem('userType', JSON.stringify(uType));
        this.userType = JSON.parse(localStorage.getItem('userType'));
        if (this.userType === 'OWNER') {
          this.router.navigateByUrl('/owner-login');
        } else {
          this.router.navigateByUrl('/guest-login');
        }

      }
  }

}
