import { CommonService } from './../services/common.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-select-language',
  templateUrl: './select-language.component.html',
  styleUrls: ['./select-language.component.scss']
})
export class SelectLanguageComponent implements OnInit {

  // public language_status: number;
  // public language_type: string;
  public languageStatus: number;
  public languageType: string;

  constructor(private route: ActivatedRoute, private commonService: CommonService, private router: Router) {}

  ngOnInit(): void {

    this.selectLanguage(this.languageStatus, this.languageType);
  }

  selectLanguage(lstatus: number, ltype: string) {
      if (lstatus !== undefined && ltype !== undefined) {
        const languageObject = {statusCode: lstatus, languageType: ltype};
        localStorage.setItem('languageObject', JSON.stringify(languageObject));
        this.router.navigateByUrl('/select-user-type');
      }
  }

}
