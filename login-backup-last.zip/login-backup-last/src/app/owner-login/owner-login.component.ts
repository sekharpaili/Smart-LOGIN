import { CommonService } from './../services/common.service';
import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-owner-login',
  templateUrl: './owner-login.component.html',
  styleUrls: ['./owner-login.component.scss']
})
export class OwnerLoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  userLogedInError = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private commonService: CommonService
  ) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
    });

    $('.toggle-password').click(function() {
      $(this).toggleClass('fa-eye-slash');
      const input = $('.owner-pwd');
      if (input.attr('type') === 'password') {
        input.attr('type', 'text');
      } else {
        input.attr('type', 'password');
      }
    });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }

    if (this.f.username.value !== undefined && this.f.password.value !== undefined) {
      this.commonService.ownerLogin(this.f.username.value, this.f.password.value)
      .subscribe(
          res => {
            const resultContent = res;
            const queryString = '<h3>Thank you for verifying your account.</h3>';
            if (resultContent.indexOf(queryString) > -1) {
                this.router.navigateByUrl('/welcome-screen');
            } else {
              this.userLogedInError = true;
              this.router.navigateByUrl('/owner-login');
            }
          },
          err => {
            this.router.navigateByUrl('/owner-login');
            console.log('ERROR in Owner login', err);
          }
      );
    }

  }

  forgotPassword() {
    localStorage.setItem('forgot-password', 'owner');
    this.router.navigateByUrl('forgot-password');
  }

}
