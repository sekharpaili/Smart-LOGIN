import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from './services/common.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public senderId: any;
  public pageId: any;
  public channelId: any;

  public senderInfo: any = {};
  public selectedLanguage = 'jp';

  constructor(private commonServices: CommonService, private router: Router, public translate: TranslateService) {
    const queryParams = new URLSearchParams(window.location.search);
    if (queryParams.get('sender_id') && queryParams.get('page_id') && queryParams.get('channel_id')) {
      this.senderInfo.senderId = queryParams.get('sender_id');
      this.senderInfo.pageId = queryParams.get('page_id');
      this.senderInfo.channelId = queryParams.get('channel_id');
      localStorage.setItem('senderInfoForGuestLogin', JSON.stringify(this.senderInfo));
    }

    if (queryParams.get('lang')) {
      this.selectedLanguage = queryParams.get('lang');
      localStorage.setItem('selectedLanguage', this.selectedLanguage);
    }
    translate.addLangs(['en', 'jp']);
    translate.setDefaultLang(this.selectedLanguage);
  }

  ngOnInit() {
    if (this.senderInfo.senderId && this.senderInfo.pageId  && this.senderInfo.channelId ) {
      this.commonServices.getUserStatus(this.senderInfo.senderId, this.senderInfo.pageId, this.senderInfo.channelId).subscribe(
        res => {
          this.router.navigateByUrl('/select-user-type');
        },
        err => {
          console.log('ERROR', err);
          this.router.navigateByUrl('/page-not-found');
        }
      );
    } else {
      this.router.navigateByUrl('/page-not-found');
    }
  }

}
