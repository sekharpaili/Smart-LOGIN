import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from './../services/common.service';

declare var $: any;

@Component({
  selector: 'app-guest-login',
  templateUrl: './guest-login.component.html',
  styleUrls: ['./guest-login.component.scss']
})

export class GuestLoginComponent implements OnInit {
  // isActive = false;
  // firstInputState = false;
  // secondInputState = false;
  // thirdInputState = false;
  // fourthInputState = false;
  // fifthInputState = false;
  // sixthInputState = false;

  guestLoginForm: FormGroup;
  submitAttempt = false;
  userLogedInError = false;

  errorText = '';
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private commonService: CommonService
  ) { }

  ngOnInit(): void {
    this.guestLoginForm = this.fb.group({
      first: ['', Validators.required],
      second: ['', Validators.required],
      third: ['', Validators.required],
      fourth: ['', Validators.required],
      fifth: ['', Validators.required],
      sixth: ['', Validators.required],
      seventh: ['', Validators.required],
      eighth: ['', Validators.required]
    });

    $('.toggle-password').click(function() {
      $(this).toggleClass('fa-eye-slash');
      const input = $('.guest-login-input');
      if (input.attr('type') === 'password') {
        input.attr('type', 'text');
      } else {
        input.attr('type', 'password');
      }
    });
  }

  guestLogin() {
    this.submitAttempt = true;
    const loginString = this.toString(this.guestLoginForm.value);
    if (loginString !== undefined && loginString.length === 8) {
      this.commonService.guestLogin(loginString).subscribe(
        res => {
          if (res.status === 1) {
            const senderInfo = JSON.parse(localStorage.getItem('senderInfoForGuestLogin'));
            if (senderInfo.pageId && senderInfo.senderId && senderInfo.channelId) {
              const payLoad = {
                user_id: res.user.user_id,
                user_name: res.user.user_name,
                first_name: res.user.first_name,
                last_name: res.user.last_name,
                address: res.user.address,
                email_id: res.user.email_id,
                phone_no: res.user.phone_no,
                alt_phone_no: res.user.alt_phone_no,
                act_authenticated: res.user.act_authenticated,
                act_enabled: res.user.act_enabled,
                dob: res.user.dob,
                gender: res.user.gender,
                isMaster: res.user.isMaster,
                status: 'success',
                page_id: senderInfo.pageId,
                sender_id: senderInfo.senderId,
                channel_id: senderInfo.channelId,
                sessionId: res.sessionId
              };
              this.commonService.liveSmartLoginStatus(payLoad).subscribe(
                data => {
                  if (data.toLocaleLowerCase() === 'ok') {
                    this.router.navigateByUrl('/welcome-screen');
                  }
                }
              );
            }

          } else {
            this.userLogedInError = true;
            console.log('Enter correct otp');
            // this.router.navigateByUrl('/guest-login');
          }

        },
        err => {
          console.log('Error in Guest login');
          this.router.navigateByUrl('/guest-login');
        }
      );
    }
  }

  toString(otpObj) {
    let result = '';
    Object.keys(otpObj).forEach(k => {
      result = result + otpObj[k];
    });
    return result;
  }


  toggle(status: boolean, field: string): void {
    this.submitAttempt = false;
    // this[`${field}InputState`] = status;
  }

  keyTab(event: any, field: string): void {
    const nextBlock = event.target.parentElement.nextElementSibling;
    const previousBlock = event.target.parentElement.previousElementSibling;
    if (event.key === 'Enter' && !nextBlock && this.guestLoginForm.controls[field].value) {
      this.toggle(false, 'sixth');
      // this.next();
    }
    if (event.key !== 'Backspace' && nextBlock && this.guestLoginForm.controls[field].value) {
      nextBlock.children[0].focus();
    }
    if (event.key === 'Backspace' && previousBlock) {
      previousBlock.children[0].focus();
    }
  }

  forgotPasscode() {
    localStorage.setItem('forgot-password', 'guest');
    this.router.navigateByUrl('forgot-password');
  }

}
